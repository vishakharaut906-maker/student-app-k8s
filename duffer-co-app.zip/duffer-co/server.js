require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'duffer2026';
const DB_FILE = path.join(__dirname, 'data', 'db.json');

const DEFAULT_PRODUCTS = [
  {id:'p1', name:'Chikankari Embroidered Kurta', category:'Embroidery', price:1899, wholesale:1199, moq:12, stock:84, custom:true, desc:'Hand-guided chikankari thread-work on breathable cotton. Made to order in any size.', image:''},
  {id:'p2', name:'Thread-Work Panel Shirt', category:'Embroidery', price:1699, wholesale:1099, moq:12, stock:60, custom:true, desc:'Contrast panel shirt with custom thread-work down the placket.', image:''},
  {id:'p3', name:'Oversized Graphic Tee — Men', category:'Men T-Shirts', price:799, wholesale:449, moq:24, stock:150, custom:true, desc:'240 GSM heavyweight cotton, boxy fit, ready for a custom back print.', image:''},
  {id:'p4', name:'Oversized Graphic Tee — Women', category:'Women T-Shirts', price:799, wholesale:449, moq:24, stock:120, custom:true, desc:"Same heavyweight cotton in a relaxed women's cut.", image:''},
  {id:'p5', name:'Cargo Lowers — Men', category:'Lowers', price:1399, wholesale:849, moq:18, stock:95, custom:false, desc:'Six-pocket cargo lowers in stretch cotton twill.', image:''},
  {id:'p6', name:'Track Lowers — Women', category:'Lowers', price:1199, wholesale:749, moq:18, stock:70, custom:false, desc:'Tapered track lowers with a soft brushed interior.', image:''},
  {id:'p7', name:'Custom Embroidered Hoodie', category:'Embroidery', price:2199, wholesale:1499, moq:12, stock:40, custom:true, desc:'Fleece hoodie with your logo or name embroidered on the chest.', image:''},
  {id:'p8', name:'Denim Panel Shirt', category:'Men T-Shirts', price:1599, wholesale:999, moq:18, stock:55, custom:false, desc:'Washed denim shirt with a relaxed streetwear fit.', image:''},
];

// in-memory admin session tokens (reset on server restart, which is fine —
// admin just logs in again)
const activeTokens = new Set();

// --- tiny JSON-file "database" -------------------------------------------
function readDB() {
  if (!fs.existsSync(DB_FILE)) {
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify({ products: DEFAULT_PRODUCTS, enquiries: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function writeDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function requireAuth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!token || !activeTokens.has(token)) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

// --- auth ------------------------------------------------------------------
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body || {};
  if (password === ADMIN_PASSWORD) {
    const token = crypto.randomBytes(24).toString('hex');
    activeTokens.add(token);
    return res.json({ token });
  }
  res.status(401).json({ error: 'Wrong password' });
});
app.post('/api/admin/logout', requireAuth, (req, res) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  activeTokens.delete(token);
  res.json({ ok: true });
});

// --- products ---------------------------------------------------------------
app.get('/api/products', (req, res) => {
  res.json(readDB().products);
});
app.post('/api/admin/products', requireAuth, (req, res) => {
  const db = readDB();
  const product = { ...req.body, id: 'p' + Date.now() };
  db.products.push(product);
  writeDB(db);
  res.json(product);
});
app.put('/api/admin/products/:id', requireAuth, (req, res) => {
  const db = readDB();
  const idx = db.products.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.products[idx] = { ...db.products[idx], ...req.body, id: req.params.id };
  writeDB(db);
  res.json(db.products[idx]);
});
app.delete('/api/admin/products/:id', requireAuth, (req, res) => {
  const db = readDB();
  db.products = db.products.filter(p => p.id !== req.params.id);
  writeDB(db);
  res.json({ ok: true });
});

// --- enquiries (customize / wholesale / contact forms) ----------------------
app.post('/api/enquiries', (req, res) => {
  const db = readDB();
  const entry = { ...req.body, id: 'e' + Date.now(), time: new Date().toLocaleString() };
  db.enquiries.unshift(entry);
  writeDB(db);
  res.json(entry);
});
app.get('/api/admin/enquiries', requireAuth, (req, res) => {
  res.json(readDB().enquiries);
});

// fallback to the SPA for any other route (e.g. duffer.sbs/shop on refresh)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log(`DUFFER.CO server running on port ${PORT}`));
